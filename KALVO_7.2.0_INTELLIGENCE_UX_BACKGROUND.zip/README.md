# KALVO 7.2.0 — Intelligent Market & Paper-Trading Platform

**KALVO** یک محیط چندبازاری برای مشاهدهٔ داده، تحلیل زمینه‌مند، آزمایش استراتژی و مدیریت موقعیت‌های شبیه‌سازی‌شده است.

> **SEE CLEARLY · THINK DEEPLY · STAY AWARE**  
> بازار را دقیق‌تر ببین؛ تصمیم را آگاهانه‌تر بررسی کن.

## What changed in 7.2.0

- تقویم منبع‌محور با برنامهٔ انتشارهای رسمی BLS، جلسات FOMC فدرال رزرو و نشست‌های ECB. رویدادهایی که فقط تاریخ دارند، بدون ساعت ساختگی نمایش داده می‌شوند.
- خبرخوان موازی CoinDesk، Federal Reserve، BLS، ECB و SEC با allow-list دامنه، زمان انتشار، حذف تکراری و طبقه‌بندی رویداد/ریسک. این مجموعه پوشش جامع تمام رسانه‌ها و بازارها نیست.
- تحلیل عمیق AI اکنون زمینهٔ سه تایم‌فریم، سلامت مظنه، حافظهٔ توصیفی نماد، خبرهای مرتبط و تقویم رسمی را در اختیار می‌گیرد. AI باید دادهٔ گمشده را اعلام کند و سطح حمایت/مقاومت نسازد.
- حافظهٔ معاملات بسته‌شده با آمار توصیفی recency-weighted و بازهٔ عدم‌قطعیت؛ این یک شبکهٔ عصبی آموزش‌دیده یا احتمال برد آینده نیست.
- سرویس اختیاری Android foreground با حالت sticky برای پایش دفترکل تمرینی پس از خارج‌شدن از صفحهٔ برنامه؛ وضعیت آخرین چرخه ثبت می‌شود و قفل بین‌فرایندی از اجرای دوبارهٔ مدیر موقعیت جلوگیری می‌کند.
- فونت سیستم Noto در صورت وجود، شکل‌دهی فارسی/عربی، و fallback به Roboto.
- انیمیشن انتقال صفحه و فشردن دکمه؛ صداهای کوتاه tap/success/alert با پیش‌فرض خاموش.
- پروفایل چیدمان خودکار برای عرض‌های مختلف موبایل و تبلت، اندازهٔ فونت، تراکم و رنگ تأکیدی قابل‌شخصی‌سازی.
- اعلان‌ها با ثبت در صندوق داخلی، مجوز اندروید ۱۳+، شناسهٔ پایدار و محدودکنندهٔ تکرار.

## Product and safety boundary

- **تمام معامله‌ها، سفارش‌ها، کیف پول و Auto-Trade در این نسخه شبیه‌سازی‌شده‌اند.** آداپتورهای بازار فقط دادهٔ عمومی خواندنی دریافت می‌کنند؛ هیچ سفارش، واریز یا برداشت زنده به صرافی ارسال نمی‌شود.
- Auto-Trade فقط در دفترکل محلی تمرینی اجرا می‌شود. نبود دادهٔ تازه/دوطرفه، خطای AI، نبود اطمینان کافی یا نقض کنترل محلی ریسک یعنی عدم ورود.
- محدودیت‌های ریسک و اهرم موجود افزایش داده نشده‌اند. حافظهٔ آماری هم مجوز افزایش بودجهٔ ریسک نمی‌دهد.
- خبر به‌تنهایی سیگنال جهت‌دار نیست. خبرخوان یک مجموعهٔ منبع محدود است؛ نبود خبر در این فیدها ثابت نمی‌کند رویدادی رخ نداده است.
- AI context و حافظهٔ آماری برای توضیح و ارزیابی هستند، نه تضمین سود یا پیش‌بینی قطعی.

## Android background monitoring

- سرویس در Buildozer با `foreground:sticky` تعریف شده و فقط بعد از روشن‌کردن گزینهٔ «نظارت پس‌زمینه» در تنظیمات شروع می‌شود.
- سرویس از همان دیتابیس محلی استفاده می‌کند، مدیر موقعیت را از طریق قفل بین‌فرایندی اجرا می‌کند و فقط رویدادهای دفترکل شبیه‌سازی را پایش می‌کند.
- Android می‌تواند سرویس را به‌دلیل مدیریت باتری، محدودیت سازنده، توقف اجباری، ری‌استارت دستگاه یا مجوزها متوقف کند. `sticky` درخواست بازیابی است، **تضمین ۲۴/۷ نیست**. Force Stop با شروع مجدد برنامه تفاوت دارد.
- سرویس برای جلوگیری از مصرف بی‌رویه، WakeLock دائمی نگه نمی‌دارد. نظارت دائمی واقعی و مستقل از گوشی به یک backend server پایدار نیاز دارد.

## Android build identity

| Setting | Value |
|---|---|
| App title | `KALVO` |
| Version | `7.2.0` |
| Package | `org.kalvo.lab.kalvomax` |
| Minimum Android API | `24` |
| Compile/target API | `33` |
| ABI | `arm64-v8a` |
| Output | Debug APK |
| Launcher icon | `assets/kalvo_icon.png` (512×512) |

The Android target is currently API 33 for the pinned python-for-android toolchain. Before a public store release, review the then-current target API and foreground-service-type requirements; Android 14+ requires a declared foreground service type for foreground services.

## Tests and local validation

```bash
python -m pip install -r requirements.txt
python -m pip install pytest
python -m pytest -q
python -m unittest discover -s tests -q
python -m compileall -q main.py apex services tests tools
python tools/validate_project.py
```

The layout breakpoint matrix is tested at 320, 360, 393, 432, 600, 768 and 1024 dp. This is not a substitute for screenshot/interaction testing on physical phones. Kivy, Android SDK/NDK and Buildozer are not installed in the local validation environment, so the real APK build and device UI pass must be confirmed by GitHub Actions and an Android device.

## Build APK with GitHub Actions

1. Extract the ZIP and place its **contents** in the root of the repository.
2. Preserve `.github/workflows/build-apk.yml` exactly.
3. Commit and push to `main` or `master`, or run `KALVO 7.2.0 Android APK` manually from Actions.
4. Download `KALVO-7.2.0-Android-APK` from the successful run's Artifacts.

The uploaded APK is a debug artifact, not a release-signed Play Store package.

## Keys and private configuration

Existing project API-key configuration has been preserved as requested. The real `.env` file is not bundled. **Do not publish this repository or APK as public:** any key embedded in source code or an APK can be extracted. API keys must not be treated as private once shipped inside a client application.

## Known limitations

- No real exchange order-routing or live-account integration exists.
- The adaptive memory is statistical, interpretable and sample-limited; it does not train a neural model.
- AI's role in automated decisions remains subject to deterministic quote/data and risk gates; it is not an unconstrained autonomous trader.
- News and macro calendar coverage is bounded to configured public sources.
- Android service survival, notifications, Arabic typography, animations and screen layout still require real-device validation across OEMs and screen sizes.
- Full professional UI redesign across every page is an ongoing phase; the 7.2.0 changes add responsive behavior and visual feedback but do not claim parity with a large exchange app.
